"""Service layer — business logic between routes and core engines."""
