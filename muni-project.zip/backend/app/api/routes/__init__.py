"""HTTP routes (thin controllers — all logic lives in services)."""
