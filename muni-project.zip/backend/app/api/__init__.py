"""API layer: router aggregation, DI providers, route modules."""
