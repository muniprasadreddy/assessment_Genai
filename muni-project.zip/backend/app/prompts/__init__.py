"""Prompt templates (kept as versioned code, not loose files)."""
