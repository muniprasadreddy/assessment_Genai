"""Retrieval subsystem: vector retriever, LLM access, and answer generation."""
