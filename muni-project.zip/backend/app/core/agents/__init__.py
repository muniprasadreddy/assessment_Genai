"""CrewAI multi-agent orchestration (agentic RAG mode)."""
