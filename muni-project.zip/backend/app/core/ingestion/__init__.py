"""Ingestion subsystem: loading, chunking, embedding, vector store, pipeline."""
