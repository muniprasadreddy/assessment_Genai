"""Core subsystems: config, logging, errors, ingestion, RAG, agents, tracing."""
