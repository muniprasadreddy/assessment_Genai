"""Shared Pydantic models for the API layer."""
